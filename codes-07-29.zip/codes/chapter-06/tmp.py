import numpy as np
from collections import Counter

def prune_tree(node):
    """
    对决策树进行自底向上的C4.5剪枝（误差估计法）。
    node: 决策树节点（Node/DiscreteNode/ContinuousNode），需有labels属性。
    剪枝原则参考C4.5算法伪代码。
    """

    # 递归终止条件：叶节点
    if node.is_leaf:
        # 叶节点的错误数
        m = sum(np.array(node.labels) != node.class_label)
        return m, 1  # 错误数, 叶节点数

    # 递归计算所有子节点的误差
    if node.discret:
        # 离散节点
        subtree_error = 0
        leaf_count = 0
        for child in node.children.values():
            m_i, l_i = prune_tree(child)
            subtree_error += m_i
            leaf_count += l_i
    else:
        # 连续节点
        m_left, l_left = prune_tree(node.l_child)
        m_right, l_right = prune_tree(node.r_child)
        subtree_error = m_left + m_right
        leaf_count = l_left + l_right

    # 该节点自身剪枝后的误差（变为叶节点）
    # 预测类别为最多类别
    most_common_label = Counter(node.labels).most_common(1)[0][0]
    m = sum(np.array(node.labels) != most_common_label)
    E_subtree = subtree_error + 0.5 * leaf_count
    E_pruned = m + 0.5

    # 剪枝条件
    if E_pruned <= E_subtree:
        # 剪枝为叶节点
        node.is_leaf = True
        node.class_label = most_common_label
        # 移除子节点
        if node.discret:
            node.children = {}
        else:
            node.l_child = None
            node.r_child = None
        return m, 1  # 剪枝后该节点是叶节点
    else:
        # 不剪枝，返回子树误差统计
        return subtree_error, leaf_count

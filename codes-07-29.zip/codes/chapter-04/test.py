import numpy as np
import matplotlib.pyplot as plt

font_size = 20
# 设置模型复杂度范围
complexity = np.linspace(0.1, 6, 300)

# 定义偏差²、方差和总误差的函数关系
bias_squared = 1 / (1 + complexity) - 0.05                  # 偏差²：随复杂度增加而单调递减
variance = 0.02 * (complexity ** 2) +0.1                  # 方差：随复杂度增加呈非线性单调递增
total_error = bias_squared + variance                # 总误差 = 偏差² + 方差

# 创建图像
plt.figure(figsize=(8, 6))

# 绘制偏差²、方差和总误差曲线
plt.plot(complexity, bias_squared, '--', marker='o', markersize=5, markevery=50, label='偏差²(bias²)', color='blue', linewidth=2)
plt.plot(complexity, variance, '--', marker='s', markersize=5, markevery=50,label='方差(variance)', color='green', linewidth=2)
plt.plot(complexity, total_error, label='总误差', color='red', linewidth=2)

# 标注最佳复杂度（总误差最小时的位置）
optimal_point = complexity[np.argmin(total_error)]
plt.axvline(optimal_point, color='purple', linestyle=':', linewidth=2)
plt.text(optimal_point + 0.1, 0.8, '最佳复杂度', color='purple', fontsize=font_size, fontname='SimSun')

# 设置标题、坐标轴标签
plt.xlabel('模型复杂度', fontsize=font_size, fontname='SimSun')
plt.ylabel('误差', fontsize=font_size, fontname='SimSun')

# 添加图例和网格
plt.legend(fontsize=11, prop={'family': 'SimSun', 'size': font_size})
plt.gca().set_xticks([])
plt.gca().set_yticks([])
plt.ylim(0, 1.3)

plt.tight_layout(rect=[0, 0, 1, 1])
# 显示图像
plt.show()
